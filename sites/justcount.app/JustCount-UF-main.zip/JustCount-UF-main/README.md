# JustCount
Början för vårat UF 



## verktyg
Pocketbase
[https://justcount-pb.superdator.spetsen.net/](https://justcount-pb.superdator.spetsen.net/)
_för att logga in lägg till ```/_/``` i slutet_
