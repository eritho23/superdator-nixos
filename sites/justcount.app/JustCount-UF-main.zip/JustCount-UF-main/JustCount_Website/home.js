// JavaScript for Navbar Highlight and Hamburger Menu

// Add active class to the clicked navbar link and remember it
document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.querySelectorAll('.navbar_links');

    // Check localStorage for the active link on page load
    const activeLink = localStorage.getItem('activeNavLink');
    if (activeLink) {
        navLinks.forEach(link => {
            if (link.getAttribute('href') === activeLink) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }

    // Add click event to update active link
    navLinks.forEach(link => {
        link.addEventListener('click', function () {
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            localStorage.setItem('activeNavLink', this.getAttribute('href'));
        });
    });

    // Hamburger menu toggle
    const mobileMenu = document.getElementById('mobile-menu');
    const navbarMenu = document.querySelector('.navbar_menu');

    mobileMenu.addEventListener('click', () => {
        mobileMenu.classList.toggle('is-active');
        navbarMenu.classList.toggle('active');
    });
});
