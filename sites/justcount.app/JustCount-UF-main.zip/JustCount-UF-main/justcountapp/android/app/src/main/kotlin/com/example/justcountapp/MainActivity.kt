package com.example.justcountapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
