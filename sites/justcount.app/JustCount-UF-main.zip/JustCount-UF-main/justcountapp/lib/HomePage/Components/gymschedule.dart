import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:justcountapp/imported_classes.dart';
import 'package:video_player/video_player.dart';
import '/blocs/gym_schedule/gym_schedule_bloc.dart';
import '/blocs/gym_schedule/gym_schedule_event.dart';
import '/blocs/gym_schedule/gym_schedule_state.dart';
import '/blocs/video_player/video_player_bloc.dart';
import '/blocs/video_player/video_player_event.dart';
import '/blocs/video_player/video_player_state.dart';

class WeekTabContainer extends StatefulWidget {
  const WeekTabContainer({super.key});

  @override
  State<WeekTabContainer> createState() => _WeekTabContainerState();
}

class _WeekTabContainerState extends State<WeekTabContainer>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;
  final List<String> daysOfWeek = [
    'Mon',
    'Tue',
    ' Wed',
    '   Thu',
    ' Fri',
    'Sat',
    'Sun'
  ];
  late TabController _tabController;

  final List<List<String>> videos = [
["https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
],
["https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",],
[],
[],
[],
[],
[]
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: daysOfWeek.length, vsync: this);

    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        context.read<GymScheduleBloc>().add(const ResetSelection());
        if (videos[_tabController.index].isNotEmpty){
        context.read<VideoPlayerBloc>().add(ChangeVideo(videos[_tabController.index][0]));
        }
        if (videos[_tabController.index].isEmpty){
          context.read<VideoPlayerBloc>().add(ChangeVideo("Rest"));
        }
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey),
        color: Color(0xFF110F0F),
      ),
      width: MediaQuery.of(context).size.width * 1.2,
      height: 250,
      padding: const EdgeInsets.all(25),
      child: DefaultTabController(
        length: daysOfWeek.length,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
          child: Column(
            children: [
              TabBar(
                controller: _tabController,
                isScrollable: false,
                tabs: daysOfWeek.map((day) => Tab(text: day)).toList(),
                labelPadding: const EdgeInsets.symmetric(horizontal: 0),
                unselectedLabelStyle: GoogleFonts.lato(
                    color: const Color(0xFFAAAAAA),
                    fontWeight: FontWeight.w900,
                    fontSize: 17),
                labelStyle: GoogleFonts.lato(
                  fontWeight: FontWeight.w900,
                  fontSize: 17.5,
                  color: Colors.white,
                  shadows: [
                    const Shadow(
                      blurRadius: 25,
                      color: Colors.white,
                      offset: Offset(0, 0),
                    ),
                  ],
                ),
                dividerColor: Colors.transparent,
                indicator: const BoxDecoration(),
              ),
              Expanded(
                child: BlocBuilder<GymScheduleBloc, GymScheduleState>(
                  builder: (context, state) {
                    return TabBarView(
                      controller: _tabController,
                      children: daysOfWeek.map((day) {
                        int tabIndex = daysOfWeek.indexOf(day);
                        if (videos[tabIndex].isEmpty){
                          return Center(child: Text("Restish" , style: TextStyle(fontSize: 34, color: Colors.white),));
                        }
                        else{
                        return GridView.builder(
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 4,
                            childAspectRatio: 1,
                          ),
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount:  videos[tabIndex].length,
                          itemBuilder: (context, index) {
                            return SelectableCard(
                                index: index,
                                isSelected: index == state.selectedIndex,
                                onTap: () {
                                  context
                                      .read<GymScheduleBloc>()
                                      .add(SelectCard(index));
                                  context.read<VideoPlayerBloc>().add(ChangeVideo(
                                      videos[_tabController.index][index]));
                                      print(_tabController.index);
                                });
                          },
                        );
                        }
                      }).toList(),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class VideoComponent extends StatefulWidget {
  const VideoComponent({super.key});

  @override
  State<VideoComponent> createState() => _VideoComponentState();
}

class _VideoComponentState extends State<VideoComponent> {
  late VideoPlayerController _controller;
  late Future<void> _initializeVideoPlayerFuture;
  bool isRestDay = false;

  @override
  void initState() {
    super.initState();
    final selectedVideo = context.read<VideoPlayerBloc>().state.selectedVideo;
    if (selectedVideo == "Rest") {
      isRestDay = true;
    } else {
      _controller = VideoPlayerController.networkUrl(Uri.parse(selectedVideo));
      _initializeVideoPlayerFuture = _controller.initialize();
    }
    
  }

  @override
  void dispose() {
    if (!isRestDay){
    _controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<VideoPlayerBloc, VideoPlayerState>(
      listener: (context, state) {
        setState(() {
          if (state.selectedVideo == "Rest") {
            isRestDay = true;
          }
          else {
           _controller.dispose();
           _controller = VideoPlayerController.networkUrl(Uri.parse(state.selectedVideo));
           _initializeVideoPlayerFuture = _controller.initialize();
           isRestDay = false;
          }
        });
      },
      child: isRestDay? AspectRatio(aspectRatio: 16/9, child: Center(child: Text("😴", style: TextStyle(fontSize: 50),),),) : FutureBuilder(
          future: _initializeVideoPlayerFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return GestureDetector(
                onTap: () {
                  setState(() {
                    if (_controller.value.isPlaying) {
                      _controller.pause();
                    } else {
                      _controller.play();
                    }
                  });
                },
                child: AspectRatio(
                  aspectRatio: 16/9,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: AspectRatio(
                      aspectRatio: _controller.value.aspectRatio,
                      child: VideoPlayer(_controller),
                    ),
                  ),
                ),
              );
            } else {
              return AspectRatio(
                aspectRatio: 16 / 9,
                child: const Center(
                  child: CircularProgressIndicator(),
                ),
              );
            }
          },
        ),
    );
  }
}

class GymScheduleComponents extends StatelessWidget {
  const GymScheduleComponents({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => GymScheduleBloc(),
        ),
        BlocProvider(
          create: (context) => VideoPlayerBloc(),
        ),
      ],
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          WeekTabContainer(),
          VideoComponent(),
        ],
      ),
    );
  }
}
