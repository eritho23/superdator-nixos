import "package:flutter/material.dart";
import 'gymschedule.dart';
import 'track_nutrition.dart';


class DailyCounter extends StatelessWidget {
  const DailyCounter({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
      child: SizedBox(
          width: MediaQuery.of(context).size.width * 1,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Daily Counter',
                style: TextStyle(
                  color: Color.fromARGB(255, 100, 95, 95),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
             
             Container(
                  height: 57,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(colors: [
                      Color(0xFF524DFE),
                      Color(0xFF46166F),  
                      Color(0xFF46166F),
                    ], begin: Alignment.bottomLeft, end: Alignment.topRight,
                    transform: GradientRotation(2.3)),
                    
                  ),
                  
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text(
                        '🔥365',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 25,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      Text(
                        'Gold 🏆',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 25,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          )),
    );
  }
}

class GymTrackTabcontroller extends StatelessWidget {
 const GymTrackTabcontroller({super.key});
  @override
  Widget build(BuildContext context) {
    return const Expanded(
    
      child: DefaultTabController(
        length: 2,
        child: Padding(
          
          padding:  EdgeInsets.symmetric(horizontal: 25.0, vertical: 10),        
            child: Column(
              
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                 TabBar(
                    tabAlignment: TabAlignment.center,
                    isScrollable: false,
                    tabs: <Widget>[
                      Tab(text: 'Gym Schedule'),
                      Tab(text: 'Track Nutrition'),
                    ],
                   
                    unselectedLabelStyle: TextStyle(
                      color: Color(0xFF404040),
                      fontWeight: FontWeight.w900,
                      fontSize: 20,
                    ),
                    labelStyle: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 20,
                      color: Colors.white,
                      shadows: [
                        Shadow(
                          blurRadius: 25,
                          color: Colors.white,
                          offset: Offset(0, 0),
                        ),
                      ],
                    ),
                    dividerColor: Colors.transparent,
                    indicator: BoxDecoration(),
                    splashFactory: NoSplash.splashFactory,
                    overlayColor: WidgetStatePropertyAll<Color>(Colors.transparent),
                    indicatorColor: Colors.transparent,),
            
                  Expanded(
                      child: TabBarView(
                          physics:  NeverScrollableScrollPhysics(),
                          children: [
                            GymScheduleComponents(),
                            TrackNutrition(),
                          ],
                        ),
                      ),
                
                
                
              ],
            ),
          ),
      ),
    );
  }
}
