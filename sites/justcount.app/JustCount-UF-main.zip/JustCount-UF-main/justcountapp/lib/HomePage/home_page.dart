import 'package:flutter/material.dart';
import 'NestedPages/profile_page.dart';
// import 'Components/view2.dart';
import 'Components/shared_components.dart';
import '../imported_classes.dart';
import 'package:google_fonts/google_fonts.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
     return Scaffold(
        appBar: AppBar(
          centerTitle: false,
          backgroundColor: Colors.transparent,
          title: GradientText(widget.title,
              gradient: LinearGradient(
                colors: <Color>[Colors.purple.shade900, Colors.purple.shade800],
              )),
          titleTextStyle: GoogleFonts.lato(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            fontSize: 30,
          ),
          toolbarHeight: 70,
          leadingWidth: 100,
          actions:  <Widget>[
            Padding(
              padding: EdgeInsets.only(right: 16.0), // Adjust the value as needed
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ProfilePage() ),
                  );
                },
                child: CircleAvatar(
                  backgroundColor: Colors.blue,
                  child: Text('AK'),
                  
                ),
              ),
              
            ),
          ],
        ),
        
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[const DailyCounter(), GymTrackTabcontroller()],
          ),
        ),
      );
  }
}
