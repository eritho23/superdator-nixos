import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'Leaderboard/leaderboard.dart';
import 'HomePage/home_page.dart';
import 'LoginPage/login_page.dart';
import '/imported_classes.dart';
import 'ProgressTracker/progresstracker.dart';
import 'ProgressTracker/progressview.dart';
import 'ProgressTracker/progressprovider.dart';
import 'package:justcountapp/ProgressTracker/selection_provider.dart';

  // Planer för senare, om man loggar ut ska LoginPage bli root
  
  // WidgetsFlutterBinding.ensureInitialized();
  //SharedPreferences prefs = await SharedPreferences.getInstance();
  // bool isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
  
void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => Body1Provider()),
        ChangeNotifierProvider(create: (_) => Body2Provider()),
        ChangeNotifierProvider(create: (_) => Body3Provider()),
        ChangeNotifierProvider(create: (_) => Body4Provider()),
        ChangeNotifierProvider(create: (_) => ProgressProvider()), // Add ProgressProvider
        ChangeNotifierProvider(create: (_) => SelectionProvider()),
      ],
      child: const MaterialApp(
        home: LoginPage(),
      ),
    ),
  );
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.black.withOpacity(0.002),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      //debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
          textTheme: GoogleFonts.latoTextTheme(),
          useMaterial3: true,
          scaffoldBackgroundColor: Colors.transparent),
      home: const MyHomePage(title: 'Hi Alexander!'),
    );
  }
}

class BottomNavBar extends StatefulWidget {
  const BottomNavBar({super.key});
  @override
  _BottomNavBarState createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  final List<Widget> _pages = [MyApp(), Leaderboard(), ProgressTracker()];
  int _activePage = 0;

  void _onItemTapped(int index) {
    setState(() {
      _activePage = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF110f0f),
            Color.fromARGB(255, 26, 10, 40),
            Color(0xFF000000)
          ],
        ),
      ),
      child: Scaffold(
          backgroundColor: Colors.transparent,
          bottomNavigationBar: CurvedNavigationBar(
            index: _activePage,
            height: 70.0,
            items: <Widget>[
              Icon(
                Icons.home,
                size: 30,
                color: _activePage == 0 ? Colors.black : Colors.white,
              ),
              Icon(
                Icons.leaderboard,
                size: 30,
                color: _activePage == 1 ? Colors.black : Colors.white,
              ),
              Icon(
                Icons.note_add,
                size: 30,
                color: _activePage == 2 ? Colors.black : Colors.white,
              ),
            ],
            color: Color(0xFF110f0f),
            buttonBackgroundColor: Colors.white,
            backgroundColor: Colors.transparent,
            animationCurve: Curves.easeInOut,
            animationDuration: const Duration(milliseconds: 400),
            onTap: _onItemTapped,
          ),
          body: FadeIndexedStack(
              key: ValueKey("stack"), index: _activePage, children: _pages)),
    );
  }
}
