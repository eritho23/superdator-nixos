import 'package:flutter/material.dart';

class LeaderViewer extends StatelessWidget {
  const LeaderViewer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Colors.transparent,

            ),

            child: 
            SizedBox(
            height: 250,
            width: 400, // Define a height for the Stack
            child: Stack(
              children: [
                Positioned(
                  bottom: 34,
                  left: 7,
                  child: Container(
                    padding: EdgeInsets.all(3), // Space between the outline and the CircleAvatar
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xFFC4C4C4),
                          spreadRadius: 3,
                          blurRadius: 5,
                          offset: Offset(0, 0), // changes position of shadow
                        ),
                      ],
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFFC4C4C4),
                          Color(0xFF696666),
                        ],
                        begin: Alignment.bottomLeft,
                        end: Alignment.topRight,
                        transform: GradientRotation(2.3),
                      ),
                    ),
                  child: CircleAvatar(
                    backgroundColor: Colors.blue,
                    child: Text("BK"),
                    radius: 45,
                  ),
                  ),
                ),
                                Positioned(
                  bottom: 179,
                  left: 200,
                  child: 
                  Container(
                    child: CustomPaint(
                      size: Size(35, 35),
                      painter: MyPainter(),
                    ),
                ),
                ),
                Positioned(
                  bottom: 74,
                  left: 120,
                  child: Container(
                    padding: EdgeInsets.all(3), // Space between the outline and the CircleAvatar
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xFFFCFF69).withOpacity(0.9),
                          spreadRadius: 0,
                          blurRadius: 150,
                          offset: Offset(0, 0),
                          blurStyle: BlurStyle.solid // changes position of shadow
                        ),
                      ],
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFFFCFF69),
                          Color(0xFFEFBF04),
                        ],
                        begin: Alignment.bottomLeft,
                        end: Alignment.topRight,
                        transform: GradientRotation(2.3),
                      ),
                    ),
                    child: CircleAvatar(
                      backgroundColor: Colors.red,
                      child: Text("AK"),
                      radius: 60, // Adjust the radius as needed
                      
                    ),
                  ),
                ),
                Positioned(
                  bottom: 39,
                  left: 260,
                  child: Container(
                    padding: EdgeInsets.all(3), // Space between the outline and the CircleAvatar
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color:Color(0xFFCE8946),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: Offset(0, 0), // changes position of shadow
                        ),
                      ],
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFFCE8946),
                          Color(0xFF996C13),
                        ],
                        begin: Alignment.bottomLeft,
                        end: Alignment.topRight,
                        transform: GradientRotation(2.3),
                      ),
                    ),
                  child: CircleAvatar(
                    backgroundColor: Colors.green,
                    child: Text("WB"),
                    radius: 35,
                  ),
                  ),
                ),
                Positioned(
                  bottom: 24,
                  left: 260,
                child: 
                Text("Willfried Bigira",
                style: TextStyle(
                  color: Color(0xFF996C13),
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                ),
                ),),
                Positioned(
                  bottom: 54,
                  left: 110,
                  child: Text("Alexander Kaipainen",
                  style: TextStyle(
                  color: Color(0xFFFCFF69),
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                ),
                ),),
                Positioned(
                  bottom: 14,
                  left: 0,
                  child: Text("Beni-Juste Ngabire",
                  style: TextStyle(
                  color: Color(0xFF696666),
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                ),
                ),),
                Positioned(child: Text("420 000",
                                  style: TextStyle(
                  color: Color(0xFFFCFF69),
                  fontSize: 15,
                  fontWeight: FontWeight.w900,),
                ),
                bottom: 40,
                left: 150,
                ),
                Positioned(child: Text("200 000",
                                  style: TextStyle(
                  color: Color(0xFF996C13),
                  fontSize: 10,
                  fontWeight: FontWeight.w900,),
                ),
                bottom: 10,
                left: 280,
                ),
                Positioned(child: Text("300 000",
                                  style: TextStyle(
                  color: Color(0xFF696666),
                  fontSize: 12,
                  fontWeight: FontWeight.w900,),
                ),
                bottom: 0,
                left: 30,
                ),
              ],

            ),
          ),
        
          ),

          Container(
            child: 
              SizedBox(
                height: 250,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                        colors: <Color> [Colors.transparent, Colors.black],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        transform: GradientRotation(2.3),
                    ),

                  ),
                  child: Column(

                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Container(
                        height: 250,
                        child:
                        ListView(
                        shrinkWrap: true,
                        children: [
                          ListTile(
                            title: Text("4. Anton Sundström"),
                            subtitle: Text("Points: 69000"),
                            leading: CircleAvatar(
                              backgroundColor: Colors.black,
                              child: Text("AS"),
                            ),
                          ),
                          ListTile(
                            title: Text("5. Trym Karlsson"),
                            subtitle: Text("Points: 60000"),
                            leading: CircleAvatar(
                              backgroundColor: Colors.purple,
                              child: Text("TK"),
                            ),
                          ),
                          ListTile(
                            title: Text("6. Oliver Sjödahl"),
                            subtitle: Text("Points: 59000"),
                            leading: CircleAvatar(
                              backgroundColor: Colors.yellow,
                              child: Text("OS"),
                            ),
                          ),
                          ListTile(
                            title: Text("7.Alex Korton Widell"),
                            subtitle: Text("Points: 42000"),
                            leading: CircleAvatar(
                              backgroundColor: Colors.lightGreen,
                              child: Text("AW"),
                            ),
                          ),
                          ListTile(
                            title: Text("8. Edvin Vikström"),
                            subtitle: Text("Points: 33000"),
                            leading: CircleAvatar(
                              backgroundColor: Colors.deepOrange,
                              child: Text("EV"),
                            ),
                          ),
                          ListTile(
                            title: Text("9. Yousif Ahmed Al-Kaabi Mohammed Mustafa Al-Kaabi Al-Saidi Al-Mansoori"),
                            subtitle: Text("Points: 9110"),
                            leading: CircleAvatar(
                              backgroundColor: Colors.amber,
                              child: Text("YM"),
                            ),
                          ),
                          ListTile(
                            title: Text("10. Gustav شاذ Sandell"),
                            subtitle: Text("Points: 9000"),
                            leading: CircleAvatar(
                              backgroundColor: Colors.lime,
                              child: Text("GS"),
                            ),
                          ),
                        ],
                      ),

                      )
                      
                    ],
                  ),
                ),
              )
            ),
        ],
            ),
          );
  }
}

class MyPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.yellow
      ..style = PaintingStyle.fill;

    final path = Path()
      ..moveTo(size.width*0, size.height * 0.5)
      ..lineTo(size.width * 0, size.height * 0.1)
      ..lineTo(size.width * 0.4, size.height * 0.5)
      ..lineTo(size.width * 0.6, size.height * 0.1)
      ..lineTo(size.width * 0.8, size.height * 0.5)
      ..lineTo(size.width*1.2,size.height*0.1)
      ..lineTo(size.width*1.2, size.height*0.5)
      ..lineTo(size.width*1.2, size.height * 0.9)
      ..lineTo(0, size.height * 0.9)
      ..close();

    canvas.save();
    canvas.translate(size.width / 2, size.height / 2); // Move the origin to the center of the canvas
    canvas.rotate(0.55); // Rotate the canvas by 0.5 radians
    canvas.translate(-size.width / 2, -size.height / 2); // Move the origin back to the top-left corner
    canvas.drawPath(path, paint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class Regional extends LeaderViewer {
  const Regional({super.key});
}

class National extends LeaderViewer {
  const National({super.key});
}

class Global extends LeaderViewer {
  const Global({super.key});
}
