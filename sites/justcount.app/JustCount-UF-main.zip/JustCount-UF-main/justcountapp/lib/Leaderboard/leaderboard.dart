import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'leaderview.dart';
import 'package:justcountapp/HomePage/Components/shared_components.dart';
import 'package:justcountapp/imported_classes.dart';
import 'package:justcountapp/HomePage/home_page.dart';
import 'package:justcountapp/HomePage/NestedPages/profile_page.dart';

class Leaderboard extends StatefulWidget {
  const Leaderboard({super.key});
  @override
  State<Leaderboard> createState() => LeaderboardState();
}

class LeaderboardState extends State<Leaderboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: Colors.transparent,
        title: GradientText("Leaderboard",
            gradient: LinearGradient(
              colors: <Color>[Colors.purple.shade900, Colors.purple.shade800],
            )),
        titleTextStyle: GoogleFonts.lato(
          color: Colors.white,
          fontWeight: FontWeight.w900,
          fontSize: 30,
        ),
        toolbarHeight: 70,
        leadingWidth: 100,
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(right: 16.0), // Adjust the value as needed
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProfilePage()),
                );
              },
              child: CircleAvatar(
                backgroundColor: Colors.blue,
                child: Text('AK'),
              ),
            ),
          ),
        ],
      ),
      body: const DefaultTabController(
        length: 3,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 25.0, vertical: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              TabBar(
                tabAlignment: TabAlignment.center,
                isScrollable: false,
                tabs: <Widget>[
                  Tab(text: 'Regional'),
                  Tab(text: 'National'),
                  Tab(text: "Global")
                ],
                unselectedLabelStyle: TextStyle(
                  color: Color(0xFF404040),
                  fontWeight: FontWeight.w900,
                  fontSize: 20,
                ),
                labelStyle: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 20,
                  color: Colors.white,
                  shadows: [
                    Shadow(
                      blurRadius: 25,
                      color: Colors.white,
                      offset: Offset(0, 0),
                    ),
                  ],
                ),
                dividerColor: Colors.transparent,
                indicator: BoxDecoration(),
                splashFactory: NoSplash.splashFactory,
                overlayColor: WidgetStatePropertyAll<Color>(Colors.transparent),
                indicatorColor: Colors.transparent,
              ),
              Expanded(
                child: TabBarView(
                  physics: NeverScrollableScrollPhysics(),
                  children: [
                    Regional(),
                    National(),
                    Global(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}