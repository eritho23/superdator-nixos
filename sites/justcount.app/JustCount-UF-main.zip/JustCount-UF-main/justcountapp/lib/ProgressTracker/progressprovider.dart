import 'package:flutter/material.dart';
class Body1Provider with ChangeNotifier {
  List<String> _exercises = [];
  Map<int, String> _weights = {};
  Map<int, String> _reps = {};

  List<String> get exercises => _exercises;
  Map<int, String> get weights => _weights;
  Map<int, String> get reps => _reps;

  void addExercise(String exercise) {
    _exercises.add(exercise);
    notifyListeners();
  }
  void removeExercise(int index) {
      _exercises.removeAt(index);
      print("Removed exercise at index $index");
      notifyListeners();
  }
  void updateWeight(int index, String weight) {
    _weights[index] = weight;
    notifyListeners();
  }

  void updateReps(int index, String reps) {
    _reps[index] = reps;
    notifyListeners();
  }
}

class Body2Provider with ChangeNotifier {
  List<String> _exercises = [];
  Map<int, String> _weights = {};
  Map<int, String> _reps = {};

  List<String> get exercises => _exercises;
  Map<int, String> get weights => _weights;
  Map<int, String> get reps => _reps;

  void addExercise(String exercise) {
    _exercises.add(exercise);
    notifyListeners();
  }
  void removeExercise(int index) {
    if (index >= 0 && index < _exercises.length) {
      _exercises.removeAt(index);
      notifyListeners();
    }
  }
  void updateWeight(int index, String weight) {
    _weights[index] = weight;
    notifyListeners();
  }

  void updateReps(int index, String reps) {
    _reps[index] = reps;
    notifyListeners();
  }
}

class Body3Provider with ChangeNotifier {
  List<String> _exercises = [];
  Map<int, String> _weights = {};
  Map<int, String> _reps = {};

  List<String> get exercises => _exercises;
  Map<int, String> get weights => _weights;
  Map<int, String> get reps => _reps;

  void addExercise(String exercise) {
    _exercises.add(exercise);
    notifyListeners();
  }
  void removeExercise(int index) {
    if (index >= 0 && index < _exercises.length) {
      _exercises.removeAt(index);
      notifyListeners();
    }
  }
  void updateWeight(int index, String weight) {
    _weights[index] = weight;
    notifyListeners();
  }

  void updateReps(int index, String reps) {
    _reps[index] = reps;
    notifyListeners();
  }
}

class Body4Provider with ChangeNotifier {
  List<String> _exercises = [];
  Map<int, String> _weights = {};
  Map<int, String> _reps = {};

  List<String> get exercises => _exercises;
  Map<int, String> get weights => _weights;
  Map<int, String> get reps => _reps;

  void addExercise(String exercise) {
    _exercises.add(exercise);
    notifyListeners();
  }
  void removeExercise(int index) {
    if (index >= 0 && index < _exercises.length) {
      _exercises.removeAt(index);
      notifyListeners();
    }
  }
  void updateWeight(int index, String weight) {
    _weights[index] = weight;
    notifyListeners();
  }

  void updateReps(int index, String reps) {
    _reps[index] = reps;
    notifyListeners();
  }
}

class ProgressProvider with ChangeNotifier {
  List<Exercise> _exercises = [];
  // Example of storing weights/reps by exercise index
  final Map<int, String> _weights = {};
  final Map<int, String> _reps = {};

  List<Exercise> get exercises => _exercises;

  void addExercise(String name) {
    _exercises.add(Exercise(name: name));
    notifyListeners();
  }

  void removeExercise(int index) {
    if (index >= 0 && index < _exercises.length) {
      _exercises.removeAt(index);  // Remove reps data for the exercise
      notifyListeners();
    }
  }

  void updateWeight(int index, String weight) {
    if (index >= 0 && index < _exercises.length) {
      _exercises[index].weight = weight;
      notifyListeners();
    }
  }

  void updateReps(int index, String reps) {
    if (index >= 0 && index < _exercises.length) {
      _exercises[index].reps = reps;
      notifyListeners();
    }
  }
}

class Exercise {
  String name;
  String weight;
  String reps;

  Exercise({required this.name, this.weight = '', this.reps = ''});
}