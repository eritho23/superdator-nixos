import 'package:flutter/material.dart';

class SelectionProvider with ChangeNotifier {
  bool _isSelected = false;

  bool get isSelected => _isSelected;

  void toggleSelection() {
    _isSelected = !_isSelected;
    notifyListeners();
  }

  void setSelection(bool value) {
    _isSelected = value;
    notifyListeners();
  }
}