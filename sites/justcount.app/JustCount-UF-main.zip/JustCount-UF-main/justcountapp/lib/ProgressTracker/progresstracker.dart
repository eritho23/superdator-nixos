import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:justcountapp/imported_classes.dart';
import 'package:justcountapp/ProgressTracker/progressview.dart';
import 'package:provider/provider.dart';
import 'package:justcountapp/ProgressTracker/selection_provider.dart';

class ProgressTracker extends StatefulWidget {
  const ProgressTracker({super.key});
  @override
  State<ProgressTracker> createState() => ProgressTrackerState();
}

class ProgressTrackerState extends State<ProgressTracker> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: Colors.transparent,
        title: GradientText("Progress Tracker",
          gradient: LinearGradient(
            colors: <Color>[Colors.purple.shade900, Colors.purple.shade800],
          )),
        titleTextStyle: GoogleFonts.lato(
          color: Colors.white,
          fontWeight: FontWeight.w900,
          fontSize: 30,
        ),
        toolbarHeight: 70,
        leadingWidth: 100,
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(right: 16.0), // Adjust the value as needed
            child: IconButton(
              icon: Icon(
                Icons.delete_outlined,
                color: Colors.white,
                size: 40,
                shadows: [
                  Shadow(
                    blurRadius: 25,
                    color: Colors.white,
                    offset: Offset(0, 0),
                  ),
                ],
              ),
              onPressed: () {
                Provider.of<SelectionProvider>(context, listen: false).toggleSelection();
              },
            ),
          ),
        ],
      ),
      body: DefaultTabController(
        length: 4,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5.0, vertical: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              TabBar(
                tabAlignment: TabAlignment.center,
                isScrollable: false,
                unselectedLabelStyle: TextStyle(
                  color: Color(0xFF404040),
                  fontWeight: FontWeight.w900,
                  fontSize: 20,
                ),
                labelStyle: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 20,
                  color: Colors.white,
                  shadows: [
                    Shadow(
                      blurRadius: 25,
                      color: Colors.white,
                      offset: Offset(0, 0),
                    ),
                  ],
                ),
                dividerColor: Colors.transparent,
                indicator: BoxDecoration(),
                splashFactory: NoSplash.splashFactory,
                overlayColor: MaterialStateProperty.all<Color>(Colors.transparent),
                indicatorColor: Colors.transparent,
                tabs: const [
                  Tab(
                    text: 'Chest',
                  ),
                  Tab(
                    text: 'Back',
                  ),
                  Tab(
                    text: 'Arms',
                  ),
                  Tab(
                    text: 'Legs & Abs',
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              const Expanded(
                child: TabBarView(
                  physics: NeverScrollableScrollPhysics(),
                  children: const [
                    Body1(),
                    Body2(),
                    Body3(),
                    Body4(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}