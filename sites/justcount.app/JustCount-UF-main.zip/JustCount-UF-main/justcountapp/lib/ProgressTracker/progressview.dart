import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'progressprovider.dart';
import 'selection_provider.dart';

class Progressview extends StatefulWidget {
  final String bodyPart;
  const Progressview({super.key, required this.bodyPart});

  @override
  _ProgressviewState createState() => _ProgressviewState();
}

class _ProgressviewState extends State<Progressview> with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  final ScrollController _scrollController = ScrollController();
  final Map<int, TextEditingController> weightControllers = {};
  final Map<int, TextEditingController> repsControllers = {};
  final TextEditingController textController = TextEditingController();
  
  bool isAddingExercise = false;
  late ProgressProvider provider;

  int expandedIndex = -1; // Define expandedIndex

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    provider = Provider.of<ProgressProvider>(context, listen: false);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    weightControllers.values.forEach((controller) => controller.dispose());
    repsControllers.values.forEach((controller) => controller.dispose());
    super.dispose();
  }

  void _removeContainer(int index) {
    provider.removeExercise(index);
    print("Removed exercise at index $index");
    weightControllers.remove(index); // Remove weight data for the exercise
    repsControllers.remove(index); 
  }

  @override
  Widget build(BuildContext context) {
    var provider = Provider.of<ProgressProvider>(context);
    bool isSelected = Provider.of<SelectionProvider>(context).isSelected;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 20),
            Expanded(
              child: Container(
                width: 328, // Set the width for the ListView.builder
                child: Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        controller: _scrollController,
                        itemCount: provider.exercises.length + 1, // Add one for the "Add Exercise" button
                        itemBuilder: (context, index) {
                          if (index == provider.exercises.length) {
                            return GestureDetector(
                              onTap: () {
                                setState(() {
                                  isAddingExercise = true;
                                });
                              },
                              child: Container(
                                height: 74,
                                margin: EdgeInsets.symmetric(vertical: 10.0),
                                padding: EdgeInsets.all(16.0),
                                decoration: BoxDecoration(
                                  color: Color(0xff464646).withOpacity(0.39),
                                  borderRadius: BorderRadius.circular(10.0),
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: Center(
                                  child: isAddingExercise
                                      ? TextField(
                                          controller: textController,
                                          decoration: InputDecoration(
                                            border: OutlineInputBorder(),
                                            labelText: 'Exercise Name',
                                            labelStyle: TextStyle(
                                              color: Colors.white,
                                            ),
                                          ),
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 18,
                                          ),
                                          onSubmitted: (value) {
                                            if (value.isNotEmpty) {
                                              context.read<ProgressProvider>().addExercise(value);
                                              setState(() {
                                                isAddingExercise = false;
                                                textController.clear();
                                              });
                                            }
                                          },
                                        )
                                      : Text(
                                          'Add Exercise',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 25,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                ),
                              ),
                            );
                          } else {
                            // Initialize controllers if they don't exist
                            weightControllers.putIfAbsent(index, () => TextEditingController());
                            repsControllers.putIfAbsent(index, () => TextEditingController());

                            return GestureDetector(
                              onTap: () {
                                if (isSelected) {
                                  _removeContainer(index);
                                } else {
                                  setState(() {
                                    expandedIndex = expandedIndex == index ? -1 : index;
                                  });
                                }
                              },
                              child: AnimatedContainer(
                                duration: Duration(milliseconds: 300),
                                height: expandedIndex == index ? 169 : 74,
                                margin: EdgeInsets.symmetric(vertical: 10.0),
                                padding: EdgeInsets.all(16.0),
                                decoration: BoxDecoration(
                                  color: Color(0xff464646).withOpacity(0.39),
                                  borderRadius: BorderRadius.circular(10.0),
                                  
                                  border: isSelected ? Border.all(color: Colors.red) : Border.all(color: Colors.grey),
                                ),
                                child: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    Text(
                                    provider.exercises[index].name, // Use the String value directly
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 25,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    if (expandedIndex == index) ...[
                                      SizedBox(height: 19),
                                      AnimatedContainer(
                                        duration: Duration(milliseconds: 1000),
                                        decoration: BoxDecoration(
                                           gradient: LinearGradient(colors: [
                                            Color(0xFF524DFE).withOpacity(0.5),
                                            Color(0xFF46166F).withOpacity(0.5),  
                                            Color(0xFF46166F).withOpacity(0.5),
                                            ],
                                           ),
                                          borderRadius: BorderRadius.circular(10.0),
                                        ),
                                        child:
                                      Column(children: [
                                        SizedBox(height: 5),
                                      Row(
                                        
                                        children: [

                                        SizedBox(width: 20,),
                                        Text("Weight", style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 15, fontWeight: FontWeight.bold),),
                                        SizedBox(width: 155,),
                                        Text("Reps", style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 15, fontWeight: FontWeight.bold),),
                                        ],),
                                      Row(children: [
                                      SizedBox(width: 20,),
                                        Container(
                                          width: 40,
                                          child: TextField(
                                            controller: weightControllers[index],
                                            textAlign: TextAlign.center,
                                        decoration: InputDecoration(
                                          
                                          hintText: "0",
                                          hintStyle: TextStyle(
                                            color: Colors.white,
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                           onChanged: (value) {
                                          provider.updateWeight(index, value);
                                          },
                                      ),),

                                      Container( height: 28, alignment:  Alignment.topCenter, child: Text('kg', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),),),
                                      
                                        
                                      SizedBox(width: 140,),
                                      Container(
                                        width: 40,
                                        child:TextField(
                                          textAlign: TextAlign.center,
                                          controller: repsControllers[index],
                                        decoration: InputDecoration(
                                          hintText: "0",
                                          hintStyle: TextStyle(
                                            color: Colors.white,
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                         onChanged: (value) {
                                          provider.updateReps(index, value);
                                          },
                                      ),)
                                                               
                                      
                                      ],
                                      ),
                                      ],
                                      ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                              ),
                            );
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Body1 extends Progressview {
  const Body1({super.key}) : super(bodyPart: 'Body1');
}

class Body2 extends Progressview {
  const Body2({super.key}) : super(bodyPart: 'Body2');
}

class Body3 extends Progressview {
  const Body3({super.key}) : super(bodyPart: 'Body3');
}

class Body4 extends Progressview {
  const Body4({super.key}) : super(bodyPart: 'Body4');
}

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => Body1Provider()),
        ChangeNotifierProvider(create: (_) => Body2Provider()),
        ChangeNotifierProvider(create: (_) => Body3Provider()),
        ChangeNotifierProvider(create: (_) => Body4Provider()),
        ChangeNotifierProvider(create: (_) => SelectionProvider()),
      ],
      child: MaterialApp(
        home: Body1(), // Change this to navigate to different body parts
      ),
    ),
  );
}
