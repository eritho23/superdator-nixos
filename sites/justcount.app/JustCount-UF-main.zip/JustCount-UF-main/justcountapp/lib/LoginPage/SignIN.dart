import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'login_page.dart'; // Import the LoginPage

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  bool _isTermsAccepted = false; // Track whether terms are accepted
  String _email = ''; // Store the email input
  String? _emailError; // Store the email validation error message

  bool _validateEmail(String email) {
    // Regex pattern for general email validation
    final regex = RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
    return regex.hasMatch(email);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 80), // Increased space below the top
            Align(
              alignment: Alignment.centerLeft,
              child: ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [Colors.purple, Colors.blue],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ).createShader(bounds),
                child: Text(
                  "Create your account",
                  style: GoogleFonts.openSans(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 40), // Increased space below the title
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Glowing "Register" TextButton
                TextButton(
                  onPressed: () {},
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.5), // Glow color
                          blurRadius: 120, // Glow spread
                          spreadRadius: 6, // Glow intensity
                        ),
                      ],
                    ),
                    child: Text(
                      "Register",
                      style: GoogleFonts.openSans(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Colors.white.withOpacity(0.8), // Text glow color
                            blurRadius: 10, // Text glow spread
                          ),
                        ],
                      ),
                    ),
                  ),
                  style: TextButton.styleFrom(
                    splashFactory: NoSplash.splashFactory, // Remove splash effect
                  ),
                ),
                const SizedBox(width: 3), // Adjustable space between buttons
                TextButton(
                  onPressed: () {
                    // Navigate to the LoginPage with a swipe-to-right transition
                    Navigator.push(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation, secondaryAnimation) => const LoginPage(),
                        transitionsBuilder: (context, animation, secondaryAnimation, child) {
                          const begin = Offset(0.0, 0.0); // Start from the right
                          const end = Offset.zero; // End at the center
                          const curve = Curves.easeInOut; // Smooth transition
                          var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
                          var offsetAnimation = animation.drive(tween);

                          return SlideTransition(
                            position: offsetAnimation,
                            child: child,
                          );
                        },
                        transitionDuration: const Duration(milliseconds: 300), // Adjust duration
                      ),
                    );
                  },
                  child: Text(
                    "Log In",
                    style: GoogleFonts.openSans(
                      fontSize: 18,
                      color: Colors.grey,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: TextButton.styleFrom(
                    splashFactory: NoSplash.splashFactory, // Remove splash effect
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30), // More space before form fields
            TextField(
              style: GoogleFonts.openSans(color: Colors.white),
              cursorColor: const Color(0xFFFFFFFF), // Set cursor color to white
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.email, color: Colors.white),
                hintText: "Email",
                hintStyle: GoogleFonts.openSans(color: Colors.grey),
                filled: true,
                fillColor: const Color(0xFF1D1B1B),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: Colors.white),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: Color(0xFFFFFFFF)),
                ),errorText: _emailError, // Display error message if email is invalid
              ),
                onChanged: (value) {
                setState(() {
                  _email = value; // Store the email input
                  _emailError = _validateEmail(value) ? null : "Please enter a valid email address"; // Validate email
                });
              },
            ),
            const SizedBox(height: 12),
            TextField(
              style: GoogleFonts.openSans(color: Colors.white),
              cursorColor: const Color(0xFFFFFFFF), // Set cursor color to white
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.person, color: Colors.white),
                hintText: "Username",
                hintStyle: GoogleFonts.openSans(color: Colors.grey),
                filled: true,
                fillColor: const Color(0xFF1D1B1B),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: Colors.white),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: Color(0xFFFFFFFF)),
              ),
            ),
            ),const SizedBox(height: 12),
            TextField(
              style: GoogleFonts.openSans(color: Colors.white),
              cursorColor: const Color(0xFFFFFFFF), // Set cursor color to white
              obscureText: true,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.lock, color: Colors.white),
                hintText: "Password",
                hintStyle: GoogleFonts.openSans(color: Colors.grey),
                filled: true,
                fillColor: const Color(0xFF1D1B1B),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: Colors.white),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: Color(0xFFFFFFFF)),
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              style: GoogleFonts.openSans(color: Colors.white),
              cursorColor: const Color(0xFFFFFFFF), // Set cursor color to white
              obscureText: true,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.lock, color: Colors.white),
                hintText: "Repeat Password",
                hintStyle: GoogleFonts.openSans(color: Colors.grey),
                filled: true,
                fillColor: const Color(0xFF1D1B1B),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: Colors.white),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: Color(0xFFFFFFFF)),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Checkbox(
                  value: _isTermsAccepted,
                  onChanged: (bool? value) {
                    setState(() {
                      _isTermsAccepted = value ?? false; // Update the state
                    });
                  },
                  activeColor: const Color(0xFF524DFE), // Set checkbox color to #524DFE
                ),
                Text("I agree to the ", style: GoogleFonts.openSans(color: Colors.white)),
                Text("terms and conditions",
                    style: GoogleFonts.openSans(
                        color: Colors.white, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isTermsAccepted ? () {
                // Add functionality for "Sign Up" here
              } : null,
              child: Text(
                "Sign up",
                style: GoogleFonts.openSans(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 60),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: const BorderSide(color: Colors.white),
                ),
                splashFactory: NoSplash.splashFactory, // Remove splash effect
              ),
            ),
            const SizedBox(height: 40),
            Center(
              child: Text("───────── Or ─────────", style: GoogleFonts.openSans(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.white)),
            ),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.g_translate, color: Colors.black),
              label: Text("Continue with Google", style: GoogleFonts.openSans()),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                minimumSize: const Size(double.infinity, 60),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                splashFactory: NoSplash.splashFactory, // Remove splash effect
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.apple, color: Colors.white),
              label: Text("Continue with Apple", style: GoogleFonts.openSans()),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 60),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: const BorderSide(color: Colors.white),
                ),
                splashFactory: NoSplash.splashFactory, // Remove splash effect
              ),
            ),
          ],
        ),
      ),
    );
  }
}
