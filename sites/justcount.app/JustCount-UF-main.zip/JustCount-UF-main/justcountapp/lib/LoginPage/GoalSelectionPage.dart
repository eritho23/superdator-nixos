import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'PhysicalInformation.dart';

class GoalSelectionPage extends StatefulWidget {
  const GoalSelectionPage({Key? key}) : super(key: key);

  @override
  _GoalSelectionPageState createState() => _GoalSelectionPageState();
}

class _GoalSelectionPageState extends State<GoalSelectionPage> {
  // Track the selected goal index
  int? selectedIndex;

  // List of goals
  final List<String> goals = [
    'Bulk',
    'Cut',
    'Mini Cut',
    'Maintain',
    'Condition',
    'Stay fit',
    'Basket-playmaker',
    'Fotball-goalkeeper',
  ];

  // For storing the search input
  String searchQuery = '';

  // Controller for the search bar
  final TextEditingController _searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    // Filter goals based on the search query
    final filteredGoals = goals
        .where((goal) => goal.toLowerCase().contains(searchQuery.toLowerCase()))
        .toList();

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),
                  // Gradient Header: "What's your Goal"
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      colors: [Colors.purple, Colors.blue],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: Text(
                      "What's your Goal",
                      style: GoogleFonts.openSans(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  // Search Bar
                  TextField(
                    controller: _searchController,
                    style: GoogleFonts.openSans(
                      color: Colors.white, // Set the text color to white
                    ),
                    cursorColor: Colors.white, // Set the cursor color to white
                    decoration: InputDecoration(
                      hintText: 'Search for your goal',
                      hintStyle: GoogleFonts.openSans(
                        color: Colors.white.withOpacity(0.5),
                      ),
                      filled: true,
                      fillColor: const Color(0xFF1D1B1B),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none,
                      ),
                      prefixIcon: const Icon(
                        Icons.search,
                        color: Colors.white,
                      ),
                      // Clear search button
                      suffixIcon: searchQuery.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.close, color: Colors.white),
                              onPressed: () {
                                setState(() {
                                  searchQuery = '';
                                  _searchController.clear();
                                });
                              },
                            )
                          : null,
                    ),
                    onChanged: (value) {
                      setState(() {
                        searchQuery = value; // Update search query
                      });
                    },
                  ),
                  const SizedBox(height: 24),
                  // Subheader: "Question 2/3"
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Text(
                      "Question 2/3",
                      style: GoogleFonts.openSans(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  // Goal List or No Match Message
                  if (filteredGoals.isEmpty)
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(height: 40),
                          Icon(
                            Icons.search_off,
                            size: 60,
                            color: Colors.white.withOpacity(0.5),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'No matching goals found',
                            style: GoogleFonts.openSans(
                              color: Colors.white.withOpacity(0.5),
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: filteredGoals.length,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            // Update the selected index
                            setState(() {
                              selectedIndex = goals.indexOf(filteredGoals[index]);
                            });
                          },
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 4.0),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1D1B1B),
                              borderRadius: BorderRadius.circular(10),
                              border: selectedIndex == goals.indexOf(filteredGoals[index])
                                  ? Border.all(
                                      color: Colors.white,
                                      width: 2.0,
                                    )
                                  : Border.all(
                                      color: const Color(0x63464646), // 39% opacity of #464646
                                      width: 1.0,
                                    ),
                              boxShadow: selectedIndex == goals.indexOf(filteredGoals[index])
                                  ? [
                                      BoxShadow(
                                        color: Colors.white.withOpacity(0.5),
                                        blurRadius: 10,
                                        spreadRadius: 2,
                                      ),
                                    ]
                                  : null,
                            ),
                            child: ListTile(
                              title: Text(
                                filteredGoals[index],
                                style: GoogleFonts.openSans(
                                  color: Colors.white,
                                  fontSize: 16,
                                ),
                              ),
                              trailing: const Icon(
                                Icons.chevron_right,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  const SizedBox(height: 24),
                  // Next Button
                  ElevatedButton(
                    onPressed: () {
                      // Navigate to PhysicalInfoPage
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const PhysicalInfoPage(),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(double.infinity, 60),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: const BorderSide(color: Colors.white),
                      ),
                    ),
                    child: Text(
                      "Next",
                      style: GoogleFonts.openSans(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}