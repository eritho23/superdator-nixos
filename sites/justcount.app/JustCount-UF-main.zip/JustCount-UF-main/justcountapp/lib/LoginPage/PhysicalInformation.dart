import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const Color primaryBackground = Color(0xFF1D1B1B);
  static const Color borderColor = Color(0xFF464646);
  static const Color white = Colors.white;
  static const Color grey = Colors.grey;
  static const Color red = Colors.red;
}

class AppTextStyles {
  static TextStyle openSans({double fontSize = 16, FontWeight fontWeight = FontWeight.normal, Color color = Colors.white}) {
    return GoogleFonts.openSans(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color,
    );
  }
}

class PhysicalInfoPage extends StatefulWidget {
  const PhysicalInfoPage({super.key});

  @override
  State<PhysicalInfoPage> createState() => _PhysicalInfoPageState();
}

class _PhysicalInfoPageState extends State<PhysicalInfoPage> {
  String? _selectedGender;
  String? _selectedFitnessLevel;
  bool _hasGymAccess = false;
  String? _selectedHeightUnit = 'cm';
  String? _selectedWeightUnit = 'kg';

  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _feetController = TextEditingController();
  final TextEditingController _inchesController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _weeklyWorkoutController = TextEditingController();

  // FocusNodes for managing focus
  final FocusNode _heightFocusNode = FocusNode();
  final FocusNode _feetFocusNode = FocusNode();
  final FocusNode _inchesFocusNode = FocusNode();
  final FocusNode _weightFocusNode = FocusNode();
  final FocusNode _ageFocusNode = FocusNode();
  final FocusNode _weeklyWorkoutFocusNode = FocusNode();

  String? _heightError;
  String? _weightError;
  String? _ageError;
  String? _weeklyWorkoutError;

  @override
  void dispose() {
    // Dispose of controllers and focus nodes
    _heightController.dispose();
    _feetController.dispose();
    _inchesController.dispose();
    _weightController.dispose();
    _ageController.dispose();
    _weeklyWorkoutController.dispose();

    _heightFocusNode.dispose();
    _feetFocusNode.dispose();
    _inchesFocusNode.dispose();
    _weightFocusNode.dispose();
    _ageFocusNode.dispose();
    _weeklyWorkoutFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 22.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              // Gradient Header: "Physical Information"
              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [Colors.purple, Colors.blue],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ).createShader(bounds),
                child: Text(
                  "Physical Information",
                  style: AppTextStyles.openSans(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 18),
              // Subheader: "Question 3/3"
              Text(
                "Question 3/3",
                style: AppTextStyles.openSans(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              // Biological Gender Selection
              _buildSectionTitle("What is your gender?"),
              const SizedBox(height: 8),
              _buildGenderSelection(),
              const SizedBox(height: 24),
              // Height Input
              _buildSectionTitle("How tall are you?"),
              const SizedBox(height: 8),
              _buildHeightInput(),
              if (_heightError != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    _heightError!,
                    style: AppTextStyles.openSans(color: AppColors.red),
                  ),
                ),
              const SizedBox(height: 24),
              // Weight Input
              _buildSectionTitle("What's your weight?"),
              const SizedBox(height: 8),
              _buildWeightInput(),
              if (_weightError != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    _weightError!,
                    style: AppTextStyles.openSans(color: AppColors.red),
                  ),
                ),
              const SizedBox(height: 24),
              // Age Input
              _buildSectionTitle("What's your age?"),
              const SizedBox(height: 8),
              _buildAgeInput(),
              if (_ageError != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    _ageError!,
                    style: AppTextStyles.openSans(color: AppColors.red),
                  ),
                ),
              const SizedBox(height: 24),
              // General Fitness Level
              _buildSectionTitle("What's your general fitness level?"),
              const SizedBox(height: 8),
              _buildFitnessLevelSelection(),
              const SizedBox(height: 24),
              // Gym Access
              _buildSectionTitle("Do you have access to a gym?"),
              const SizedBox(height: 8),
              _buildGymAccessSelection(),
              const SizedBox(height: 24),
              // Weekly Workout Availability
              _buildSectionTitle("Weekly workout availability"),
              const SizedBox(height: 8),
              _buildWeeklyWorkoutInput(),
              if (_weeklyWorkoutError != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    _weeklyWorkoutError!,
                    style: AppTextStyles.openSans(color: AppColors.red),
                  ),
                ),
              const SizedBox(height: 40),
              // Next Button
              Container(
                margin: const EdgeInsets.only(bottom: 40),
                child: ElevatedButton(
                  onPressed: _validateAndSave,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                      side: const BorderSide(color: Colors.white),
                    ),
                  ),
                  child: Text(
                    "Next",
                    style: AppTextStyles.openSans(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Builds a section title text widget.
  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: AppTextStyles.openSans(
        fontSize: 18,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  /// Builds gender selection buttons.
  Widget _buildGenderSelection() {
    return Column(
      children: [
        _buildSelectionButton("Female", _selectedGender == "Female", () {
          setState(() => _selectedGender = "Female");
        }),
        const SizedBox(height: 8),
        _buildSelectionButton("Male", _selectedGender == "Male", () {
          setState(() => _selectedGender = "Male");
        }),
      ],
    );
  }

  /// Builds a custom selection button widget.
  Widget _buildSelectionButton(
      String label, bool isSelected, VoidCallback onChanged) {
    return GestureDetector(
      onTap: onChanged,
      child: Container(
        width: double.infinity,
        height: 50,
        decoration: BoxDecoration(
          color: AppColors.primaryBackground,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected ? AppColors.white : AppColors.borderColor.withOpacity(0.39),
            width: 1.0,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppColors.white.withOpacity(0.5),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ]
              : null,
        ),
        child: Center(
          child: Text(
            label,
            style: AppTextStyles.openSans(
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }

  /// Builds height input with a text field and dropdown for units.
  Widget _buildHeightInput() {
    if (_selectedHeightUnit == 'ft') {
      return Column(
        children: [
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 50,
                  child: _buildInputField(_feetController, "Feet", _feetFocusNode)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: SizedBox(
                    height: 50,
                    child: _buildInputField(_inchesController, "Inches", _inchesFocusNode)),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _buildUnitDropdown(_selectedHeightUnit, (value) {
            setState(() => _selectedHeightUnit = value);
          }, ['cm', 'ft']),
        ],
      );
    } else {
      return Row(
        children: [
          Expanded(
            child: SizedBox(
                height: 50, child: _buildInputField(_heightController, "Height", _heightFocusNode)),
          ),
          const SizedBox(width: 10),
          _buildUnitDropdown(_selectedHeightUnit, (value) {
            setState(() => _selectedHeightUnit = value);
          }, ['cm', 'ft']),
        ],
      );
    }
  }

  /// Builds weight input with a text field and dropdown for units.
  Widget _buildWeightInput() {
    return Row(
      children: [
        Expanded(
          child: SizedBox(
              height: 50, child: _buildInputField(_weightController, "Weight", _weightFocusNode)),
        ),
        const SizedBox(width: 10),
        _buildUnitDropdown(_selectedWeightUnit, (value) {
          setState(() => _selectedWeightUnit = value);
        }, ['kg', 'lbs']),
      ],
    );
  }

  /// Builds the age input text field.
  Widget _buildAgeInput() {
    return SizedBox(
        height: 50, child: _buildInputField(_ageController, "Age", _ageFocusNode));
  }

  /// Builds the fitness level selection buttons.
  Widget _buildFitnessLevelSelection() {
    return Column(
      children: [
        _buildSelectionButton("Beginner", _selectedFitnessLevel == "Beginner", () {
          setState(() => _selectedFitnessLevel = "Beginner");
        }),
        const SizedBox(height: 8),
        _buildSelectionButton(
            "Intermediate", _selectedFitnessLevel == "Intermediate", () {
          setState(() => _selectedFitnessLevel = "Intermediate");
        }),
        const SizedBox(height: 8),
        _buildSelectionButton("Advanced", _selectedFitnessLevel == "Advanced", () {
          setState(() => _selectedFitnessLevel = "Advanced");
        }),
      ],
    );
  }

  /// Builds gym access selection buttons.
  Widget _buildGymAccessSelection() {
    return Column(
      children: [
        _buildSelectionButton("Yes", _hasGymAccess, () {
          setState(() => _hasGymAccess = true);
        }),
        const SizedBox(height: 8),
        _buildSelectionButton("No", !_hasGymAccess, () {
          setState(() => _hasGymAccess = false);
        }),
      ],
    );
  }

  /// Builds weekly workout input text field.
  Widget _buildWeeklyWorkoutInput() {
    return SizedBox(
        height: 50,
        child: _buildInputField(_weeklyWorkoutController, "Workouts per week", _weeklyWorkoutFocusNode));
  }

  /// Builds a custom text input field.
  Widget _buildInputField(TextEditingController controller, String label, FocusNode focusNode) {
    return TextField(
      controller: controller,
      focusNode: focusNode,
      keyboardType: TextInputType.number,
      style: AppTextStyles.openSans(),
      cursorColor: AppColors.white,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: AppTextStyles.openSans(color: AppColors.grey),
        filled: true,
        fillColor: AppColors.primaryBackground,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(
              color: AppColors.borderColor.withOpacity(0.39), width: 1.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: AppColors.white, width: 1.0),
        ),
      ),
    );
  }

  /// Builds a dropdown for units.
  Widget _buildUnitDropdown(
      String? selectedValue, ValueChanged<String?> onChanged, List<String> items) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
        color: AppColors.primaryBackground,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: AppColors.borderColor.withOpacity(0.39),
          width: 1.0,
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Center(
        child: DropdownButton<String>(
          value: selectedValue,
          onChanged: onChanged,
          dropdownColor: AppColors.primaryBackground,
          underline: Container(),
          icon: const Icon(Icons.arrow_drop_down, color: AppColors.white),
          style: AppTextStyles.openSans(),
          items: items.map((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
        ),
      ),
    );
  }

  /// Validates inputs and saves data.
  void _validateAndSave() {
    setState(() {
      _heightError = _validateHeight();
      _weightError = _validateWeight();
      _ageError = _validateAge();
      _weeklyWorkoutError = _validateWeeklyWorkout();
    });

    if (_heightError == null &&
        _weightError == null &&
        _ageError == null &&
        _weeklyWorkoutError == null) {
      // Save data or navigate to the next page
      _saveData();
    }
  }

  /// Validates height input.
  String? _validateHeight() {
    if (_selectedHeightUnit == 'cm') {
      if (_heightController.text.isEmpty) {
        return "Please enter your height";
      }
      if (double.tryParse(_heightController.text) == null) {
        return "Please enter a valid number";
      }
    } else {
      if (_feetController.text.isEmpty || _inchesController.text.isEmpty) {
        return "Please enter your height";
      }
      if (double.tryParse(_feetController.text) == null ||
          double.tryParse(_inchesController.text) == null) {
        return "Please enter valid numbers";
      }
    }
    return null;
  }

  /// Validates weight input.
  String? _validateWeight() {
    if (_weightController.text.isEmpty) {
      return "Please enter your weight";
    }
    if (double.tryParse(_weightController.text) == null) {
      return "Please enter a valid number";
    }
    return null;
  }

  /// Validates age input.
  String? _validateAge() {
    if (_ageController.text.isEmpty) {
      return "Please enter your age";
    }
    if (int.tryParse(_ageController.text) == null) {
      return "Please enter a valid number";
    }
    return null;
  }

  /// Validates weekly workout input.
  String? _validateWeeklyWorkout() {
    if (_weeklyWorkoutController.text.isEmpty) {
      return "Please enter your weekly workout availability";
    }
    if (int.tryParse(_weeklyWorkoutController.text) == null) {
      return "Please enter a valid number";
    }
    return null;
  }

  /// Saves the collected data.
  void _saveData() {
    // TODO: Save data or navigate to the next page
    print("Data saved successfully!");
  }
}
