import 'package:equatable/equatable.dart';

abstract class VideoPlayerEvent extends Equatable {
  const VideoPlayerEvent();

  @override
  List<Object> get props => [];
}

class ChangeVideo extends VideoPlayerEvent {
  const ChangeVideo(this.videoUrl);

  final String videoUrl;

  @override
  List<Object> get props => [videoUrl];
}