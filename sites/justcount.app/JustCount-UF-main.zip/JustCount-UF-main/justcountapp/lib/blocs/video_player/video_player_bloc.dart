import 'video_player_event.dart';
import 'video_player_state.dart';
import 'package:bloc/bloc.dart';

class VideoPlayerBloc extends Bloc<VideoPlayerEvent, VideoPlayerState> {
  VideoPlayerBloc() : super(VideoPlayerState(selectedVideo: "https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4")) {
    on<ChangeVideo>((event, emit) {
      emit(VideoPlayerState(selectedVideo: event.videoUrl));
    });
  }
}