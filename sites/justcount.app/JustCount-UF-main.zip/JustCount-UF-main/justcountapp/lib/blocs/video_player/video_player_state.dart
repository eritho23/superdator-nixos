import 'package:equatable/equatable.dart';

// VideoPlayerState
class VideoPlayerState extends Equatable {
  final String selectedVideo;

  const VideoPlayerState({required this.selectedVideo});


  @override
  List<Object> get props => [selectedVideo];
}
