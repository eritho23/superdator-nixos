import 'package:equatable/equatable.dart';

// GymScheduleState
class GymScheduleState extends Equatable {
  final int selectedIndex;

  const GymScheduleState({required this.selectedIndex});

  GymScheduleState copyWith({int? selectedIndex}) {
    return GymScheduleState(
      selectedIndex: selectedIndex ?? this.selectedIndex,
    );
  }

  @override
  List<Object> get props => [selectedIndex];
}
