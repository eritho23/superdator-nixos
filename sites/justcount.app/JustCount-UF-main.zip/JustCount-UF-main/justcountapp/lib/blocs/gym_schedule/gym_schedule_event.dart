import 'package:equatable/equatable.dart';

abstract class GymScheduleEvent extends Equatable {
  const GymScheduleEvent();

  @override
  List<Object> get props => [];
}

class SelectCard extends GymScheduleEvent {
  const SelectCard(this.cardIndex);

  final int cardIndex;

  @override
  List<Object> get props => [cardIndex];
}

class ResetSelection extends GymScheduleEvent {
  const ResetSelection();
}