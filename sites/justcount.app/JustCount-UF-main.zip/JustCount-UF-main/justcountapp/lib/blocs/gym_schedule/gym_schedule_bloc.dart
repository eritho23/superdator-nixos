import 'package:bloc/bloc.dart';
import 'gym_schedule_event.dart';
import 'gym_schedule_state.dart';

class GymScheduleBloc extends Bloc<GymScheduleEvent, GymScheduleState> {
  GymScheduleBloc() : super(const GymScheduleState(selectedIndex: 0)) {
    on<SelectCard>((event, emit) {
      emit(GymScheduleState(selectedIndex: event.cardIndex));
      print("Selected card index: ${event.cardIndex}");
    });

    on<ResetSelection>((event, emit) {
      emit(GymScheduleState(selectedIndex: 0));
    });
  }
}